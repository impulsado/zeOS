#ifndef __TLS_H__
#define __TLS_H__

struct tls_block 
{
    int errno_value;
};

#endif